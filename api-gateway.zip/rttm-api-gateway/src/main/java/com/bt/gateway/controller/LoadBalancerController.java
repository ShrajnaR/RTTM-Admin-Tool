package com.bt.gateway.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.reactive.function.client.WebClient;

@RestController
@RequestMapping("/api/loadbalancer")
public class LoadBalancerController {

    private final WebClient webClient;

    public LoadBalancerController(WebClient.Builder builder) {
        this.webClient = builder.build();
    }

    @GetMapping("/resttemplate")
    public String route(@RequestParam String userId) {

        return webClient.get()
                .uri("http://rttm-admin-tool/whoami?userId=" + userId)
                .retrieve()
                .bodyToMono(String.class)
                .block();
    }

}
