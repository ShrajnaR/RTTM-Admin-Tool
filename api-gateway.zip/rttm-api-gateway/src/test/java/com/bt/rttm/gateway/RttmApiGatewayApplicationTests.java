package com.bt.rttm.gateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(properties = {
	    "spring.cloud.discovery.enabled=false",
	    "spring.cloud.loadbalancer.enabled=false"
	})
	class RttmApiGatewayApplicationTests {

	    @Test
	    void contextLoads() {
	    }
	}

