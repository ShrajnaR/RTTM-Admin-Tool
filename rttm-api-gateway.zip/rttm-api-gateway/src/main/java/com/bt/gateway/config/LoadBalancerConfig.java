package com.bt.gateway.config;

import com.bt.gateway.loadbalancer.ConsistentHashLoadBalancer;

import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.cloud.client.loadbalancer.Request;
import org.springframework.cloud.loadbalancer.annotation.LoadBalancerClient;
import org.springframework.cloud.loadbalancer.core.ReactorServiceInstanceLoadBalancer;
import org.springframework.cloud.loadbalancer.core.ServiceInstanceListSupplier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import reactor.core.publisher.Flux;

import java.util.List;

@Configuration
@LoadBalancerClient(
        name = "rttm-admin-tool",
        configuration = LoadBalancerConfig.AdminToolLBConfig.class
)
public class LoadBalancerConfig {

    @Configuration
    static class AdminToolLBConfig {

        @Bean
        ServiceInstanceListSupplier serviceInstanceListSupplier(
                DiscoveryClient discoveryClient
        ) {
            return new ServiceInstanceListSupplier() {

                @Override
                public String getServiceId() {
                    return "rttm-admin-tool";
                }

                @Override
                public Flux<List<ServiceInstance>> get() {
                    return Flux.just(
                            discoveryClient.getInstances("rttm-admin-tool")
                    );
                }

                // ✅ REQUIRED by Spring Cloud
                @Override
                public Flux<List<ServiceInstance>> get(Request request) {
                    return get();
                }
            };
        }

        @Bean
        ReactorServiceInstanceLoadBalancer consistentHashLoadBalancer(
                ServiceInstanceListSupplier supplier
        ) {
            return new ConsistentHashLoadBalancer(
                    "rttm-admin-tool",
                    supplier
            );
        }
    }
}
