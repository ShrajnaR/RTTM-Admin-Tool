package com.bt.gateway.loadbalancer;

import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.loadbalancer.*;
import org.springframework.cloud.loadbalancer.core.ReactorServiceInstanceLoadBalancer;
import org.springframework.cloud.loadbalancer.core.ServiceInstanceListSupplier;
import reactor.core.publisher.Mono;

import java.util.*;

public class ConsistentHashLoadBalancer
        implements ReactorServiceInstanceLoadBalancer {

    private static final int VIRTUAL_NODES = 100;

    private final ServiceInstanceListSupplier supplier;
    private volatile SortedMap<Integer, ServiceInstance> ring = new TreeMap<>();
    private volatile Set<String> lastInstanceIds = Collections.emptySet();

    public ConsistentHashLoadBalancer(
            String serviceId,
            ServiceInstanceListSupplier supplier
    ) {
        this.supplier = supplier;
    }

    // ⚠ DO NOT change signature (your Spring Cloud version requires this)
    @Override
    public Mono<Response<ServiceInstance>> choose(Request request) {

        return supplier.get(request).next().map(instances -> {

            if (instances.isEmpty()) {
                return new EmptyResponse();
            }

            rebuildRingIfChanged(instances);

            String key = extractKey(request);
            ServiceInstance chosen = select(key);

            System.out.println(
                    "[CONSISTENT_HASH] key=" + key +
                    " -> port=" + chosen.getPort()
            );

            return new DefaultResponse(chosen);
        });
    }

    private synchronized void rebuildRingIfChanged(List<ServiceInstance> instances) {

        Set<String> currentIds = new HashSet<>();
        for (ServiceInstance instance : instances) {
            currentIds.add(stableInstanceId(instance));
        }

        if (currentIds.equals(lastInstanceIds)) {
            return;
        }

        SortedMap<Integer, ServiceInstance> newRing = new TreeMap<>();

        for (ServiceInstance instance : instances) {
            String baseId = stableInstanceId(instance);
            for (int i = 0; i < VIRTUAL_NODES; i++) {
                int hash = hash(baseId + "#" + i);
                newRing.put(hash, instance);
            }
        }

        this.ring = newRing;
        this.lastInstanceIds = currentIds;
    }

    private ServiceInstance select(String key) {
        int hash = hash(key);
        SortedMap<Integer, ServiceInstance> tail = ring.tailMap(hash);
        return tail.isEmpty()
                ? ring.get(ring.firstKey())
                : tail.get(tail.firstKey());
    }

    private int hash(String key) {
        return key.hashCode() & 0x7fffffff;
    }

    /**
     * IMPORTANT:
     * This method is CORRECT but the data here
     * will ALWAYS be null in Spring Cloud LoadBalancer
     */
    private String extractKey(Request request) {
        if (request.getContext() instanceof RequestDataContext ctx) {
            RequestData data = ctx.getClientRequest();
            String headerKey = data.getHeaders().getFirst("X-User-Id");
            if (headerKey != null) {
                return headerKey;
            }
        }
        return "default";
    }

    private String stableInstanceId(ServiceInstance instance) {
        return instance.getInstanceId() != null
                ? instance.getInstanceId()
                : instance.getHost() + ":" + instance.getPort();
    }
}
