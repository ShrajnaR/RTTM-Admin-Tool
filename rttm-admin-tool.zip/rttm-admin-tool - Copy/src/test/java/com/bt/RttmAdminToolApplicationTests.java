package com.bt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RttmAdminToolApplicationTests {

	@Test
	void contextLoads() {
	}

}
