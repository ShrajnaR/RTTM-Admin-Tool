package com.bt.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "elements")
public class Element {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="elementId")
    private Long elementTypeId;
    @Column(nullable = false,unique = true)
    private String deviceType;
    @Column(nullable = false)
    private String reportName;
    @Column(nullable = false)
    private String deviceName;

    @Override
    public String toString() {
        return "Element{" +
                "elementTypeId=" + elementTypeId +
                ", deviceType='" + deviceType + '\'' +
                ", reportName='" + reportName + '\'' +
                ", deviceName='" + deviceName + '\'' +
                '}';
    }

}
