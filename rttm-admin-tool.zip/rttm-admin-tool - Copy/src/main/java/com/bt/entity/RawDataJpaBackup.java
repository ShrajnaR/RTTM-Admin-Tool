package com.bt.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "raw_data", indexes = {
        @Index(name = "idx_raw_ping_date", columnList = "ping_date")
})
public class RawDataJpaBackup {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // event type (if present)
    @Column(name = "event_type")
    private String eventType;

    // normalized ping date string (DD_MM_YYYY)
    @Column(name = "ping_date", length = 20)
    private String pingDate;

    // full raw payload JSON
    @Lob
    @Column(name = "payload", columnDefinition = "LONGTEXT")
    private String payload;

    // original timestamp (if parsed)
    @Column(name = "source_timestamp")
    private LocalDateTime sourceTimestamp;

    // when record was inserted
    @Column(name = "created_at")
    private LocalDateTime createdAt;
}
