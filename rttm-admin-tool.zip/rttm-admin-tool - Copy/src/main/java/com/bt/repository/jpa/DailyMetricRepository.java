package com.bt.repository.jpa;

import com.bt.entity.DailyMetric;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Repository
public interface DailyMetricRepository extends JpaRepository<DailyMetric, Long> {
    List<DailyMetric> findByMetricDate(LocalDate metricDate);
    Optional<DailyMetric> findByMetricDateAndElementName(LocalDate metricDate, String elementName);
}
