package com.bt.repository.mongo;

import com.bt.entity.RawData;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface RawDataRepository extends MongoRepository<RawData, String> {
    List<RawData> findByDeviceId(String deviceId);
    List<RawData> findBySource(String source);
    List<RawData> findBySourceTimestampBetween(LocalDateTime from, LocalDateTime to);
}
