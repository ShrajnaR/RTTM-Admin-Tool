package com.bt.controller;

import com.bt.service.AggregatorService;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.Map;

@RestController
@RequestMapping("/api/aggregator")
public class AggregatorController {

    private final AggregatorService aggregatorService;

    public AggregatorController(AggregatorService aggregatorService) {
        this.aggregatorService = aggregatorService;
    }

    @PostMapping("/run")
    public ResponseEntity<?> run(@RequestParam(value = "date", required = false)
                                 @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
                                         LocalDate date) {
        LocalDate metricDate = (date == null) ? LocalDate.now().minusDays(1) : date;
        int updated = aggregatorService.runAggregationForDate(metricDate);
        return ResponseEntity.ok(Map.of("metricDate", metricDate.toString(), "updatedGroups", updated));
    }
}
