package com.bt.controller;

import com.bt.dto.ElementDto;
import com.bt.entity.Element;
import com.bt.service.ElementService;
import lombok.AllArgsConstructor;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("api/elements")
@RequiredArgsConstructor
public class ElementController {

    private final ElementService elementService;

    @Value("${server.port}")
    private int port;

    @Value("${eureka.instance.instance-id:${spring.application.name}:${server.port}}")
    private String instanceId;

    @GetMapping("/instance-info")
    public String getInstanceInfo() {
        //return "This is instance running on port: " + port;
        return String.format("Instance ID: %s, Port: %d", instanceId, port);
    }

    //build create Element Rest API
    @PostMapping("/create")
    public ResponseEntity<ElementDto> createElementDetails(@RequestBody ElementDto element)
    {
        ElementDto elementDetails=elementService.createElement(element);
        return new ResponseEntity<>(elementDetails, HttpStatus.CREATED);
    }
    //build get elment by id
    @GetMapping("{id}")
    public ResponseEntity<ElementDto> getElementById(@PathVariable("id") Long elementTypeId)
    {
        ElementDto elm=elementService.getElementById(elementTypeId);
        return new ResponseEntity<>(elm,HttpStatus.OK);
    }
    @GetMapping("deviceName/{deviceName}")
    public ResponseEntity<List<Element>> getAllDeviceName(@PathVariable("deviceName") String deviceName)
    {
        List<Element> elements=elementService.getAllDeviceName(deviceName);
        return new ResponseEntity<>(elements, HttpStatus.OK);
    }
    @GetMapping("getAll")
    public ResponseEntity<List<ElementDto>> getAllELement()
    {
        List<ElementDto> elements=elementService.getAllElement();
        return new ResponseEntity<>(elements, HttpStatus.OK);
    }
    @PutMapping("{id}")
    public ResponseEntity<ElementDto> updateELement(@PathVariable("id") Long elementTypeId,@RequestBody ElementDto elementDto)
    {
        elementDto.setElementTypeId(elementTypeId);
        ElementDto elements=elementService.updateElement(elementDto);
        return new ResponseEntity<>(elements, HttpStatus.OK);
    }

    @DeleteMapping("delete/{id}")
    public ResponseEntity<String> deleteUser(@PathVariable("id") Long elementTypeId){
        elementService.deleteElement(elementTypeId);
        return new ResponseEntity<>("Deleted Successfully",HttpStatus.OK);
    }
}
