package com.bt.scheduler;

import com.bt.service.AggregatorService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.LocalDate;

@Component
public class AggregatorScheduler {
    private static final Logger logger = LoggerFactory.getLogger(AggregatorScheduler.class);
    private final AggregatorService aggregatorService;

    public AggregatorScheduler(AggregatorService aggregatorService) {
        this.aggregatorService = aggregatorService;
    }

    // default: every 15 hours (cron expression). Override via app.aggregator.cron
    @Scheduled(cron = "${app.aggregator.cron:0 0 0/15 * * *}")
    public void schedule() {
        LocalDate metricDate = LocalDate.now().minusDays(1);
        logger.info("Scheduled aggregator start for date {}", metricDate);
        int updated = aggregatorService.runAggregationForDate(metricDate);
        logger.info("Scheduled aggregator completed: {} groups updated for {}", updated, metricDate);
    }
}
