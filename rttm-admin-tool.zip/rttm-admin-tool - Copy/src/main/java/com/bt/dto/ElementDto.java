package com.bt.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ElementDto {
    private Long elementTypeId;
    private String deviceType;
    private String reportName;
    private String deviceName;

}
