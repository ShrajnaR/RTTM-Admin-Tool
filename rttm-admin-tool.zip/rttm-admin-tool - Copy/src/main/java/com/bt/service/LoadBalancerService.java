package com.bt.service;

public interface LoadBalancerService {
    String getInstanceInfo();
    String getInstanceInfoWithRestTemplate();
}