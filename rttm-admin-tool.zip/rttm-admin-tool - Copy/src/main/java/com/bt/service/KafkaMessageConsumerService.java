package com.bt.service;

import java.util.Map;

/**
 * Interface for consuming messages from Kafka topics.
 */
public interface KafkaMessageConsumerService {
    
    /**
     * Consume a message from a Kafka topic.
     * 
     * @param message the message payload
     * @param topic the topic from which the message was received
     * @param partition the partition of the topic
     * @param offset the offset of the message in the partition
     */
    void consume(Map<String, Object> message, String topic, int partition, long offset);
    
    /**
     * Process a received Kafka message.
     * 
     * @param message the message to process
     */
    void processMessage(Map<String, Object> message);
}
