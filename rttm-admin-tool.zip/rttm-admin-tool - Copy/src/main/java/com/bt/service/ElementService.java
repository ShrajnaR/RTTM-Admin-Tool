package com.bt.service;

import com.bt.dto.ElementDto;
import com.bt.entity.Element;

import java.util.List;

public interface ElementService {
    ElementDto createElement(ElementDto element);
    ElementDto getElementById(Long elementTypeId);

    List<ElementDto> getAllElement();
    List<Element> getAllDeviceName(String deviceName);
    ElementDto updateElement(ElementDto element);
    void deleteElement(Long ElementTypeId);
}
