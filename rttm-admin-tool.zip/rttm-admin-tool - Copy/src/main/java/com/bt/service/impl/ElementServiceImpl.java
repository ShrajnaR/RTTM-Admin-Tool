package com.bt.service.impl;

import com.bt.dto.ElementDto;
import com.bt.entity.Element;
import com.bt.mapper.ElementMapper;
import com.bt.repository.jpa.ElemetRepository;
import com.bt.service.ElementService;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

@Slf4j
@Service
public class ElementServiceImpl implements ElementService {

    @Autowired
    private ElemetRepository elemetRepository;

    @Autowired
    private RedisTemplate redisTemplate;

    @Override
    public ElementDto createElement(ElementDto elementDto) {
        //Convert ElementDto into Element JPA Entity
        Element element= ElementMapper.mapToElement(elementDto);

       Element savedElement= elemetRepository.save(element);
       
       //Convert Element JPA entity to ElementDto
       ElementDto savedElementDto = ElementMapper.mapToELementDto(savedElement);

       return savedElementDto;
    }

    @Override
    public ElementDto getElementById(Long elementTypeId) {
        Optional<Element> optionalElementm=elemetRepository.findById(elementTypeId);
        Element element=optionalElementm.get();
        return ElementMapper.mapToELementDto(element);
    }

    public List<Element> getAllDeviceName(String deviceName)
    {
        List<Element> elementCache=getList("device_Name_"+deviceName,Element.class);
        if(elementCache!=null)
        {
            return elementCache;
        }
        else {
            List<Element> elements=elemetRepository.findByDeviceName(deviceName);
            if(elements!=null)
                set("device_Name_"+deviceName,elements,300l);
            return elements;
        }
    }

    @Override
    public List<ElementDto> getAllElement() {
        List<Element> elements=elemetRepository.findAll();
        return elements.stream().map(ElementMapper::mapToELementDto).collect(Collectors.toList());
    }

    @Override
    public ElementDto updateElement(ElementDto element) {
        Element existingElement=elemetRepository.findById(element.getElementTypeId()).get();
        existingElement.setDeviceType(element.getDeviceType());
        Element updatedElement=elemetRepository.save(existingElement);
        return ElementMapper.mapToELementDto(updatedElement);
    }

    @Override
    public void deleteElement(Long elementTypeId) {
        elemetRepository.deleteById(elementTypeId);
    }

    public static class RedisService {
    }

    /*public <T> T get(String key, Class<T> entityclass)
    {
        try {
            Object o = redisTemplate.opsForValue().get(key);
            ObjectMapper mapper = new ObjectMapper();
            return mapper.readValue(o.toString(), entityclass);
        }catch (Exception e)
        {
            log.error("Exception ",e);
            return null;
        }

    }*/
    public <T> List<T> getList(String key, Class<T> entityClass) {
        try {
            Object o = redisTemplate.opsForValue().get(key);
            if (o == null) return null;

            ObjectMapper mapper = new ObjectMapper();
            return mapper.readValue(o.toString(),
                    mapper.getTypeFactory().constructCollectionType(List.class, entityClass));
        } catch (Exception e) {
            log.error("Exception ", e);
            return null;
        }
    }
    public void set(String key, Object o, Long ttl) {
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            String jsonValue = objectMapper.writeValueAsString(o);
            redisTemplate.opsForValue().set(key, jsonValue, ttl, TimeUnit.SECONDS); // ✅ store JSON
        } catch (Exception e) {
            log.error("Exception ", e);
        }
    }

}
