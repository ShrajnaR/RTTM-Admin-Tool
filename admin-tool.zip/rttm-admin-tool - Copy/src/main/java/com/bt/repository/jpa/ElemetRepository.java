package com.bt.repository.jpa;

import com.bt.entity.Element;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ElemetRepository extends JpaRepository<Element,Long> {

    List<Element> findByDeviceName(String deviceName);

}
