package com.bt.repository.jpa;

import com.bt.entity.RawDataJpaBackup;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface RawDataJpaRepository extends JpaRepository<RawDataJpaBackup, Long> {
    List<RawDataJpaBackup> findByPingDate(String pingDate);
    List<RawDataJpaBackup> findBySourceTimestampBetween(LocalDateTime start, LocalDateTime end);
}
