package com.bt.service;

import com.bt.entity.RawData;
import com.bt.entity.RawDataJpaBackup;

public interface RawDataService {
    RawDataJpaBackup saveToMysql(RawDataJpaBackup rawData);
    RawData saveToMongo(RawData rawData);
}
