package com.bt.service.impl;

import com.bt.entity.RawData;
import com.bt.entity.RawDataJpaBackup;
import com.bt.repository.jpa.RawDataJpaRepository;
import com.bt.repository.mongo.RawDataRepository;  // <-- YOUR NAME
import com.bt.service.RawDataService;
import org.springframework.stereotype.Service;

@Service
public class RawDataServiceImpl implements RawDataService {

    private final RawDataJpaRepository mysqlRepo;
    private final RawDataRepository mongoRepo; // <-- YOUR NAME

    public RawDataServiceImpl(
            RawDataJpaRepository mysqlRepo,
            RawDataRepository mongoRepo
    ) {
        this.mysqlRepo = mysqlRepo;
        this.mongoRepo = mongoRepo;
    }

    @Override
    public RawDataJpaBackup saveToMysql(RawDataJpaBackup raw) {
        return mysqlRepo.save(raw);
    }

    @Override
    public RawData saveToMongo(RawData raw) {
        return mongoRepo.save(raw); // <-- Works 100%
    }
}
