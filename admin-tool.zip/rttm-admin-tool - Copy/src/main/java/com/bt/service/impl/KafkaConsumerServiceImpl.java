package com.bt.service.impl;

import com.bt.entity.RawData;
import com.bt.entity.RawDataJpaBackup;
import com.bt.service.KafkaMessageConsumerService;
import com.bt.service.RawDataService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.Map;

@Service
public class KafkaConsumerServiceImpl implements KafkaMessageConsumerService {

    private static final Logger logger = LoggerFactory.getLogger(KafkaConsumerServiceImpl.class);

    private final RawDataService rawDataService;
    private final ObjectMapper objectMapper = new ObjectMapper();

    public KafkaConsumerServiceImpl(RawDataService rawDataService) {
        this.rawDataService = rawDataService;
    }

    @KafkaListener(
            topics = "${kafka.topic.name:rtsm-data}",
            groupId = "${spring.kafka.consumer.group-id}",
            containerFactory = "kafkaListenerContainerFactory"
    )
    @Override
    public void consume(
            @Payload Map<String, Object> message,
            @Header(KafkaHeaders.RECEIVED_TOPIC) String topic,
            @Header(KafkaHeaders.RECEIVED_PARTITION) int partition,
            @Header(KafkaHeaders.OFFSET) long offset
    ) {
        logger.info("Received message from topic {} [{}]@{}: {}", topic, partition, offset, message);
        processMessage(message);
    }

    @Override
    public void processMessage(Map<String, Object> message) {
        try {

            logger.debug("Processing message: {}", message);

            String payloadJson = objectMapper.writeValueAsString(message);
            String eventType = message.containsKey("eventType")
                    ? String.valueOf(message.get("eventType"))
                    : null;

            // Parse timestamp (supports seconds, millis, ISO, date formats)
            LocalDateTime sourceTs = extractTimestamp(message);

            // Compute ping date
            String pingDateNormalized = (sourceTs != null)
                    ? sourceTs.toLocalDate().format(DateTimeFormatter.ofPattern("dd_MM_yyyy"))
                    : LocalDate.now().format(DateTimeFormatter.ofPattern("dd_MM_yyyy"));

            /*
             * ----------------------------------------
             * 1️⃣ SAVE RAW DATA INTO MYSQL (Backup)
             * ----------------------------------------
             */
            RawDataJpaBackup backup = new RawDataJpaBackup();
            backup.setEventType(eventType);
            backup.setPayload(payloadJson);
            backup.setPingDate(pingDateNormalized);
            backup.setSourceTimestamp(sourceTs);
            backup.setCreatedAt(LocalDateTime.now());

            RawDataJpaBackup savedMysql = rawDataService.saveToMysql(backup);
            logger.info("MYSQL SAVED id={} pingDate={}", savedMysql.getId(), savedMysql.getPingDate());


            /*
             * ----------------------------------------
             * 2️⃣ SAVE RAW DATA INTO MONGO
             * ----------------------------------------
             */
            RawData mongo = new RawData();
            mongo.setSource(eventType);
            mongo.setDeviceId(null);                      // you can extract if available
            mongo.setPayload(payloadJson);
            mongo.setSourceTimestamp(sourceTs);
            mongo.setCreatedAt(LocalDateTime.now());

            RawData savedMongo = rawDataService.saveToMongo(mongo);
            logger.info("MONGO SAVED id={}", savedMongo.getId());


        } catch (Exception e) {
            logger.error("Error processing message: {}", message, e);
        }
    }

    private LocalDateTime extractTimestamp(Object obj) {
        if (!(obj instanceof Map)) return null;
        Map<String, Object> message = (Map<String, Object>) obj;

        Object ts =
                message.get("timestamp") != null ? message.get("timestamp") :
                message.get("time") != null ? message.get("time") :
                message.get("ts") != null ? message.get("ts") :
                null;

        return parseToLocalDateTime(ts);
    }


    private LocalDateTime parseToLocalDateTime(Object raw) {
        if (raw == null) return null;

        try {
            // numeric timestamp
            if (raw instanceof Number) {
                long val = ((Number) raw).longValue();
                if (val > 1_000_000_000_000L)
                    return Instant.ofEpochMilli(val).atZone(ZoneId.systemDefault()).toLocalDateTime();
                else
                    return Instant.ofEpochSecond(val).atZone(ZoneId.systemDefault()).toLocalDateTime();
            }

            // string timestamp
            String s = String.valueOf(raw).trim();

            // ISO instant
            try {
                return LocalDateTime.ofInstant(Instant.parse(s), ZoneId.systemDefault());
            } catch (Exception ignore) {}

            // formats
            DateTimeFormatter[] fmts = {
                    DateTimeFormatter.ISO_DATE_TIME,
                    DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"),
                    DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss"),
                    DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss"),
                    DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss"),
                    DateTimeFormatter.ofPattern("dd-MM-yyyy"),
                    DateTimeFormatter.ofPattern("dd/MM/yyyy"),
                    DateTimeFormatter.ofPattern("yyyy-MM-dd")
            };

            for (DateTimeFormatter f : fmts) {
                try {
                    if (f.toString().contains("HH"))
                        return LocalDateTime.parse(s, f);
                    else
                        return LocalDate.parse(s, f).atStartOfDay();
                } catch (Exception ignore) {}
            }

        } catch (Exception e) {
            logger.debug("Unable to parse timestamp {}: {}", raw, e.getMessage());
        }

        return null;
    }
}
