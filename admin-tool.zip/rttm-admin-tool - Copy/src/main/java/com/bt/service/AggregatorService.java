package com.bt.service;

import java.time.LocalDate;

public interface AggregatorService {
    int runAggregationForDate(LocalDate metricDate);
}
