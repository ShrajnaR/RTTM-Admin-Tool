package com.bt.service.impl;

import com.bt.entity.DailyMetric;
import com.bt.entity.RawDataJpaBackup;
import com.bt.repository.jpa.DailyMetricRepository;
import com.bt.repository.jpa.RawDataJpaRepository;
import com.bt.service.AggregatorService;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Service;

import jakarta.transaction.Transactional;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class AggregatorServiceImpl implements AggregatorService {

    private final RawDataJpaRepository rawDataRepository;
    private final DailyMetricRepository dailyMetricRepository;
    private final ObjectMapper objectMapper = new ObjectMapper();

    // change keys below if your payload uses different names
    private static final String PAYLOAD_KEY_ELEMENT = "deviceName";
    private static final String PAYLOAD_KEY_VALUE = "value";

    public AggregatorServiceImpl(RawDataJpaRepository rawDataRepository, DailyMetricRepository dailyMetricRepository) {
        this.rawDataRepository = rawDataRepository;
        this.dailyMetricRepository = dailyMetricRepository;
    }

    @Override
    @Transactional
    public int runAggregationForDate(LocalDate metricDate) {
        String pingDateStr = metricDate.format(DateTimeFormatter.ofPattern("dd_MM_yyyy"));

        // fetch by pingDate (fast), fallback to sourceTimestamp
        List<RawDataJpaBackup> raws = rawDataRepository.findByPingDate(pingDateStr);
        if (raws == null || raws.isEmpty()) {
            LocalDateTime start = metricDate.atStartOfDay();
            LocalDateTime end = metricDate.plusDays(1).atStartOfDay().minusNanos(1);
            raws = rawDataRepository.findBySourceTimestampBetween(start, end);
        }

        // group values by elementName
        Map<String, List<Double>> groups = new HashMap<>();
        for (RawDataJpaBackup rd : raws) {
            try {
                if (rd.getPayload() == null) continue;
                JsonNode root = objectMapper.readTree(rd.getPayload());
                String element = null;
                if (root.hasNonNull(PAYLOAD_KEY_ELEMENT)) element = root.get(PAYLOAD_KEY_ELEMENT).asText();
                else if (root.hasNonNull("device")) element = root.get("device").asText();
                if (element == null || element.isBlank()) continue;

                Double val = null;
                if (root.hasNonNull(PAYLOAD_KEY_VALUE)) {
                    JsonNode v = root.get(PAYLOAD_KEY_VALUE);
                    if (v.isNumber()) val = v.asDouble();
                    else {
                        try { val = Double.parseDouble(v.asText()); } catch (Exception ignored) {}
                    }
                } else if (root.hasNonNull("reading")) {
                    val = root.get("reading").asDouble();
                }
                if (val == null) continue;

                groups.computeIfAbsent(element, k -> new ArrayList<>()).add(val);
            } catch (Exception ignored) {}
        }

        int updated = 0;
        LocalDateTime computedAt = LocalDateTime.now(ZoneId.systemDefault());
        for (Map.Entry<String, List<Double>> e : groups.entrySet()) {
            String elementName = e.getKey();
            List<Double> vals = e.getValue();
            long count = vals.size();
            double sum = vals.stream().mapToDouble(Double::doubleValue).sum();
            double avg = count == 0 ? 0.0 : sum / count;
            double min = vals.stream().mapToDouble(Double::doubleValue).min().orElse(0.0);
            double max = vals.stream().mapToDouble(Double::doubleValue).max().orElse(0.0);

            DailyMetric dm = dailyMetricRepository.findByMetricDateAndElementName(metricDate, elementName)
                    .orElseGet(DailyMetric::new);

            dm.setMetricDate(metricDate);
            dm.setElementName(elementName);
            dm.setCountValue(count);
            dm.setSumValue(sum);
            dm.setAvgValue(avg);
            dm.setMinValue(min);
            dm.setMaxValue(max);
            dm.setComputedAt(computedAt);

            dailyMetricRepository.save(dm);
            updated++;
        }

        return updated;
    }
}
