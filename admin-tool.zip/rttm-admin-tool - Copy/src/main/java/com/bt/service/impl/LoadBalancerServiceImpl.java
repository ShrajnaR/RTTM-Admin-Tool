package com.bt.service.impl;

import com.bt.service.LoadBalancerService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.cloud.client.loadbalancer.LoadBalancerClient;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.List;

@Slf4j
@Service
public class LoadBalancerServiceImpl implements LoadBalancerService {
    private final LoadBalancerClient loadBalancer;
    private final DiscoveryClient discoveryClient;
    private final RestTemplate restTemplate;
    private final RestTemplate loadBalancedRestTemplate;

    @Autowired
    public LoadBalancerServiceImpl(
            LoadBalancerClient loadBalancer,
            DiscoveryClient discoveryClient,
            @Qualifier("restTemplate") RestTemplate restTemplate,
            @Qualifier("loadBalancedRestTemplate") RestTemplate loadBalancedRestTemplate) {
        this.loadBalancer = loadBalancer;
        this.discoveryClient = discoveryClient;
        this.restTemplate = restTemplate;
        this.loadBalancedRestTemplate = loadBalancedRestTemplate;
    }

    @Override
    public String getInstanceInfo() {
        try {
            // Get all instances of the service
            List<ServiceInstance> instances = discoveryClient.getInstances("RTTM-ADMIN-TOOL");
            if (instances.isEmpty()) {
                return "No instances available for RTTM-ADMIN-TOOL";
            }

            // Log available instances
            instances.forEach(instance ->
                    log.info("Available instance: {}:{}", instance.getHost(), instance.getPort())
            );

            // Using LoadBalancerClient to choose an instance
            ServiceInstance instance = loadBalancer.choose("RTTM-ADMIN-TOOL");
            if (instance == null) {
                return "Load balancer could not select an instance for RTTM-ADMIN-TOOL";
            }

            String url = String.format("http://%s:%s/api/elements/instance-info",
                    instance.getHost(), instance.getPort());
            log.info("Calling instance at: {}", url);

            // Use the non-load-balanced RestTemplate for direct calls
            return "Using LoadBalancerClient: " + restTemplate.getForObject(url, String.class);
        } catch (Exception e) {
            log.error("Error in getInstanceInfo: ", e);
            return "Error getting instance info: " + e.getMessage();
        }
    }

    @Override
    public String getInstanceInfoWithRestTemplate() {
        try {
            log.info("Attempting to call RTTM-ADMIN-TOOL service using load-balanced RestTemplate");
            // Use the load-balanced RestTemplate
            String result = loadBalancedRestTemplate.getForObject(
                    "http://RTTM-ADMIN-TOOL/api/elements/instance-info",
                    String.class
            );
            return "Using @LoadBalanced RestTemplate: " + result;
        } catch (Exception e) {
            log.error("Error in getInstanceInfoWithRestTemplate: ", e);
            return "Error with RestTemplate: " + e.getMessage();
        }
    }
}