//package com.bt.controller;

//import com.bt.service.LoadBalancerService;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RestController;

//@RestController
//@RequestMapping("/api/loadbalancer")
//public class LoadBalancerController {

 //   private final LoadBalancerService loadBalancerService;

  //  public LoadBalancerController(LoadBalancerService loadBalancerService) {
  //      this.loadBalancerService = loadBalancerService;
 //   }


//    @GetMapping("/client")
  //  public String getInstanceInfoUsingClient() {
   //     return loadBalancerService.getInstanceInfo();
 //   }

 //   @GetMapping("/resttemplate")
  //  public String getInstanceInfoUsingRestTemplate() {
   //     return loadBalancerService.getInstanceInfoWithRestTemplate();
   // }
// }