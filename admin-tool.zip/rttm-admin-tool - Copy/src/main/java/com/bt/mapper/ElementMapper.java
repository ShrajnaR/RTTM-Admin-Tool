package com.bt.mapper;

import com.bt.dto.ElementDto;
import com.bt.entity.Element;

public class ElementMapper {

    //convert Element JPA Entity into ElmentDto
    public static ElementDto mapToELementDto(Element element)
    {
        ElementDto elementDto= new ElementDto(
                element.getElementTypeId(),
                element.getDeviceType(),
                element.getReportName(),
                element.getDeviceName());
        return elementDto;
    }
    //convert ElementDto into Element JPA Entity
    public static Element mapToElement(ElementDto elementDto)
    {
        Element element= new Element(elementDto.getElementTypeId(),
                elementDto.getDeviceType(),
                elementDto.getReportName(),
                elementDto.getDeviceName());
        return element;
    }
}
