package com.bt.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "daily_metric", uniqueConstraints = {
        @UniqueConstraint(columnNames = {"metric_date", "element_name"})
})
public class DailyMetric {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "metric_date", nullable = false)
    private LocalDate metricDate;

    @Column(name = "element_name", nullable = false, length = 200)
    private String elementName;

    @Column(name = "count_value")
    private Long countValue;

    @Column(name = "sum_value")
    private Double sumValue;

    @Column(name = "avg_value")
    private Double avgValue;

    @Column(name = "min_value")
    private Double minValue;

    @Column(name = "max_value")
    private Double maxValue;

    @Column(name = "computed_at")
    private LocalDateTime computedAt;
}
