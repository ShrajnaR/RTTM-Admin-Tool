package com.bt.entity;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Document(collection = "raw_data")
public class RawData {
    @Id
    private String id;               // Mongo ObjectId as string

    @Field("source")
    private String source;

    @Field("device_id")
    private String deviceId;

    @Field("payload")
    private String payload;         // if storing JSON string. If you want searchable JSON, use Map<String,Object>

    @Field("source_timestamp")
    private LocalDateTime sourceTimestamp;

    @Field("created_at")
    private LocalDateTime createdAt;
}
